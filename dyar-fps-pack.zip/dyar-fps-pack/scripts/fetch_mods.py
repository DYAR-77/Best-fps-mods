"""ينزّل أحدث نسخة Fabric من كل مود (حسب mods.txt) لإصدار ماين كرافت المطلوب، مع التبعيات المطلوبة."""
import json, os, sys, urllib.parse, urllib.request

mc, root = sys.argv[1], sys.argv[2]
UA = {"User-Agent": "dyar-fps-pack/1.0 (github-actions)"}
out = os.path.join(root, "downloaded")
os.makedirs(out, exist_ok=True)
report, seen = [], set()


def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90) as r:
        return r.read()


def install(ref, why=""):
    if ref in seen:
        return
    seen.add(ref)
    try:
        q = urllib.parse.urlencode({"game_versions": json.dumps([mc]), "loaders": json.dumps(["fabric"])})
        vers = json.loads(get(f"https://api.modrinth.com/v2/project/{ref}/version?{q}"))
        if not vers:
            report.append(f"MISS  {ref}{why}: لا توجد نسخة Fabric تدعم {mc}")
            return
        v = next((x for x in vers if x.get("version_type") == "release"), vers[0])
        names = []
        for f in v["files"]:
            n = f["filename"]
            if not n.endswith(".jar") or "sources" in n or "javadoc" in n:
                continue
            open(os.path.join(out, n), "wb").write(get(f["url"]))
            names.append(n)
        report.append(f"OK    {ref}{why}: {v['version_number']} -> {', '.join(names)}")
        for d in v.get("dependencies", []):
            if d.get("dependency_type") == "required" and d.get("project_id"):
                install(d["project_id"], " (تبعية مطلوبة)")
    except Exception as e:
        report.append(f"FAIL  {ref}{why}: {e}")


for l in open(os.path.join(root, "mods.txt"), encoding="utf8"):
    slug = l.split("#")[0].strip()
    if slug:
        install(slug)
open(os.path.join(root, "MODS-REPORT.txt"), "w", encoding="utf8").write("\n".join(report) + "\n")
print("\n".join(report))
